<?php
$script = '
    <script src="https://cdn.jsdelivr.net/npm/handlebars@4.7.7/dist/handlebars.min.js"></script>
    <script src="../JS/function.js" defer></script>
    <script src="../JS/signUp.js" defer></script>
    <script src="../JS/logIn.js" defer></script>
    <script src="../JS/fetch.js" defer></script>
	<script src="../JS/dark-mode.js" defer></script>
	<script src="../JS/nav.js" defer></script>
	<script src="../JS/menu.js" defer></script>
    
    ';
