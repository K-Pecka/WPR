<?php
$style = '

    <link rel="stylesheet" href="../style/style.css">
    <link rel="stylesheet" href="../style/media.css">
    <link rel="stylesheet" href="../style/footer.css">
    <link rel="stylesheet" href="../style/nav.css">
    <link rel="stylesheet" href="../style/login.css">
    ';
