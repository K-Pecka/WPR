<?php
header("Location: ./page");
exit();
